#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,sys

def play(url, title, pic):
    if  xbmc.Player().isPlaying():
        xbmc.Player().stop()
    xlistitem = xbmcgui.ListItem( title, iconImage=pic, thumbnailImage=pic )
    xlistitem.setInfo( "video", { "Title": title } )
    xbmc.Player().play(url,xlistitem)
    sys.exit(0)	